/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class CommandLine
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  81 */   private final List<String> args = new LinkedList();
/*     */ 
/*  84 */   private final List<Option> options = new ArrayList();
/*     */ 
/*     */   protected void addArg(String arg)
/*     */   {
/*  99 */     this.args.add(arg);
/*     */   }
/*     */ 
/*     */   protected void addOption(Option opt)
/*     */   {
/* 108 */     this.options.add(opt);
/*     */   }
/*     */ 
/*     */   public List<String> getArgList()
/*     */   {
/* 117 */     return this.args;
/*     */   }
/*     */ 
/*     */   public String[] getArgs()
/*     */   {
/* 126 */     String[] answer = new String[this.args.size()];
/*     */ 
/* 128 */     this.args.toArray(answer);
/*     */ 
/* 130 */     return answer;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Object getOptionObject(char opt)
/*     */   {
/* 142 */     return getOptionObject(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public Object getOptionObject(String opt)
/*     */   {
/*     */     try
/*     */     {
/* 155 */       return getParsedOptionValue(opt);
/*     */     } catch (ParseException pe) {
/* 157 */       System.err.println("Exception found converting " + opt + " to desired type: " + pe.getMessage());
/* 158 */     }return null;
/*     */   }
/*     */ 
/*     */   public Properties getOptionProperties(Option option)
/*     */   {
/* 173 */     Properties props = new Properties();
/*     */ 
/* 175 */     for (Option processedOption : this.options) {
/* 176 */       if (processedOption.equals(option)) {
/* 177 */         List values = processedOption.getValuesList();
/* 178 */         if (values.size() >= 2)
/*     */         {
/* 180 */           props.put(values.get(0), values.get(1));
/* 181 */         } else if (values.size() == 1)
/*     */         {
/* 183 */           props.put(values.get(0), "true");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 188 */     return props;
/*     */   }
/*     */ 
/*     */   public Properties getOptionProperties(String opt)
/*     */   {
/* 202 */     Properties props = new Properties();
/*     */ 
/* 204 */     for (Option option : this.options) {
/* 205 */       if ((opt.equals(option.getOpt())) || (opt.equals(option.getLongOpt()))) {
/* 206 */         List values = option.getValuesList();
/* 207 */         if (values.size() >= 2)
/*     */         {
/* 209 */           props.put(values.get(0), values.get(1));
/* 210 */         } else if (values.size() == 1)
/*     */         {
/* 212 */           props.put(values.get(0), "true");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 217 */     return props;
/*     */   }
/*     */ 
/*     */   public Option[] getOptions()
/*     */   {
/* 226 */     Collection processed = this.options;
/*     */ 
/* 229 */     Option[] optionsArray = new Option[processed.size()];
/*     */ 
/* 232 */     return (Option[])processed.toArray(optionsArray);
/*     */   }
/*     */ 
/*     */   public String getOptionValue(char opt)
/*     */   {
/* 242 */     return getOptionValue(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   public String getOptionValue(char opt, String defaultValue)
/*     */   {
/* 253 */     return getOptionValue(String.valueOf(opt), defaultValue);
/*     */   }
/*     */ 
/*     */   public String getOptionValue(Option option)
/*     */   {
/* 264 */     if (option == null) {
/* 265 */       return null;
/*     */     }
/* 267 */     String[] values = getOptionValues(option);
/* 268 */     return values == null ? null : values[0];
/*     */   }
/*     */ 
/*     */   public String getOptionValue(Option option, String defaultValue)
/*     */   {
/* 280 */     String answer = getOptionValue(option);
/* 281 */     return answer != null ? answer : defaultValue;
/*     */   }
/*     */ 
/*     */   public String getOptionValue(String opt)
/*     */   {
/* 291 */     return getOptionValue(resolveOption(opt));
/*     */   }
/*     */ 
/*     */   public String getOptionValue(String opt, String defaultValue)
/*     */   {
/* 302 */     return getOptionValue(resolveOption(opt), defaultValue);
/*     */   }
/*     */ 
/*     */   public String[] getOptionValues(char opt)
/*     */   {
/* 312 */     return getOptionValues(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   public String[] getOptionValues(Option option)
/*     */   {
/* 323 */     List values = new ArrayList();
/*     */ 
/* 325 */     for (Option processedOption : this.options) {
/* 326 */       if (processedOption.equals(option)) {
/* 327 */         values.addAll(processedOption.getValuesList());
/*     */       }
/*     */     }
/*     */ 
/* 331 */     return values.isEmpty() ? null : (String[])values.toArray(new String[values.size()]);
/*     */   }
/*     */ 
/*     */   public String[] getOptionValues(String opt)
/*     */   {
/* 341 */     return getOptionValues(resolveOption(opt));
/*     */   }
/*     */ 
/*     */   public Object getParsedOptionValue(char opt)
/*     */     throws ParseException
/*     */   {
/* 354 */     return getParsedOptionValue(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   public Object getParsedOptionValue(Option option)
/*     */     throws ParseException
/*     */   {
/* 367 */     if (option == null) {
/* 368 */       return null;
/*     */     }
/* 370 */     String res = getOptionValue(option);
/* 371 */     if (res == null) {
/* 372 */       return null;
/*     */     }
/* 374 */     return TypeHandler.createValue(res, option.getType());
/*     */   }
/*     */ 
/*     */   public Object getParsedOptionValue(String opt)
/*     */     throws ParseException
/*     */   {
/* 387 */     return getParsedOptionValue(resolveOption(opt));
/*     */   }
/*     */ 
/*     */   public boolean hasOption(char opt)
/*     */   {
/* 415 */     return hasOption(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   public boolean hasOption(Option opt)
/*     */   {
/* 426 */     return this.options.contains(opt);
/*     */   }
/*     */ 
/*     */   public boolean hasOption(String opt)
/*     */   {
/* 436 */     return hasOption(resolveOption(opt));
/*     */   }
/*     */ 
/*     */   public Iterator<Option> iterator()
/*     */   {
/* 445 */     return this.options.iterator();
/*     */   }
/*     */ 
/*     */   private Option resolveOption(String opt)
/*     */   {
/* 455 */     opt = Util.stripLeadingHyphens(opt);
/* 456 */     for (Option option : this.options) {
/* 457 */       if ((opt.equals(option.getOpt())) || (opt.equals(option.getLongOpt()))) {
/* 458 */         return option;
/*     */       }
/*     */     }
/*     */ 
/* 462 */     return null;
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*  46 */     private final CommandLine commandLine = new CommandLine();
/*     */ 
/*     */     public Builder addArg(String arg)
/*     */     {
/*  56 */       this.commandLine.addArg(arg);
/*  57 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder addOption(Option opt)
/*     */     {
/*  68 */       this.commandLine.addOption(opt);
/*  69 */       return this;
/*     */     }
/*     */ 
/*     */     public CommandLine build() {
/*  73 */       return this.commandLine;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.CommandLine
 * JD-Core Version:    0.6.0
 */