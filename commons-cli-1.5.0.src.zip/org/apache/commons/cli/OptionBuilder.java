/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ @Deprecated
/*     */ public final class OptionBuilder
/*     */ {
/*     */   private static String longOption;
/*     */   private static String description;
/*     */   private static String argName;
/*     */   private static boolean required;
/*  47 */   private static int argCount = -1;
/*     */   private static Class<?> type;
/*     */   private static boolean optionalArg;
/*     */   private static char valueSeparator;
/*  59 */   private static final OptionBuilder INSTANCE = new OptionBuilder();
/*     */ 
/*     */   public static Option create()
/*     */     throws IllegalArgumentException
/*     */   {
/*  73 */     if (longOption == null) {
/*  74 */       reset();
/*  75 */       throw new IllegalArgumentException("must specify longopt");
/*     */     }
/*     */ 
/*  78 */     return create(null);
/*     */   }
/*     */ 
/*     */   public static Option create(char opt)
/*     */     throws IllegalArgumentException
/*     */   {
/*  89 */     return create(String.valueOf(opt));
/*     */   }
/*     */ 
/*     */   public static Option create(String opt)
/*     */     throws IllegalArgumentException
/*     */   {
/* 100 */     Option option = null;
/*     */     try
/*     */     {
/* 103 */       option = new Option(opt, description);
/*     */ 
/* 106 */       option.setLongOpt(longOption);
/* 107 */       option.setRequired(required);
/* 108 */       option.setOptionalArg(optionalArg);
/* 109 */       option.setArgs(argCount);
/* 110 */       option.setType(type);
/* 111 */       option.setValueSeparator(valueSeparator);
/* 112 */       option.setArgName(argName);
/*     */ 
/* 115 */       reset(); } finally { reset();
/*     */     }
/*     */ 
/* 119 */     return option;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasArg()
/*     */   {
/* 128 */     argCount = 1;
/*     */ 
/* 130 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasArg(boolean hasArg)
/*     */   {
/* 140 */     argCount = hasArg ? 1 : -1;
/*     */ 
/* 142 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasArgs()
/*     */   {
/* 151 */     argCount = -2;
/*     */ 
/* 153 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasArgs(int num)
/*     */   {
/* 163 */     argCount = num;
/*     */ 
/* 165 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasOptionalArg()
/*     */   {
/* 174 */     argCount = 1;
/* 175 */     optionalArg = true;
/*     */ 
/* 177 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasOptionalArgs()
/*     */   {
/* 186 */     argCount = -2;
/* 187 */     optionalArg = true;
/*     */ 
/* 189 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder hasOptionalArgs(int numArgs)
/*     */   {
/* 199 */     argCount = numArgs;
/* 200 */     optionalArg = true;
/*     */ 
/* 202 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder isRequired()
/*     */   {
/* 211 */     required = true;
/*     */ 
/* 213 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder isRequired(boolean newRequired)
/*     */   {
/* 223 */     required = newRequired;
/*     */ 
/* 225 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   private static void reset()
/*     */   {
/* 232 */     description = null;
/* 233 */     argName = null;
/* 234 */     longOption = null;
/* 235 */     type = String.class;
/* 236 */     required = false;
/* 237 */     argCount = -1;
/* 238 */     optionalArg = false;
/* 239 */     valueSeparator = '\000';
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withArgName(String name)
/*     */   {
/* 249 */     argName = name;
/*     */ 
/* 251 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withDescription(String newDescription)
/*     */   {
/* 261 */     description = newDescription;
/*     */ 
/* 263 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withLongOpt(String newLongopt)
/*     */   {
/* 273 */     longOption = newLongopt;
/*     */ 
/* 275 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withType(Class<?> newType)
/*     */   {
/* 286 */     type = newType;
/*     */ 
/* 288 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static OptionBuilder withType(Object newType)
/*     */   {
/* 303 */     return withType((Class)newType);
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withValueSeparator()
/*     */   {
/* 322 */     valueSeparator = '=';
/*     */ 
/* 324 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   public static OptionBuilder withValueSeparator(char sep)
/*     */   {
/* 346 */     valueSeparator = sep;
/*     */ 
/* 348 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  63 */     reset();
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.OptionBuilder
 * JD-Core Version:    0.6.0
 */