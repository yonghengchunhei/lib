/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ public class AlreadySelectedException extends ParseException
/*    */ {
/*    */   private static final long serialVersionUID = 3674381532418544760L;
/*    */   private final OptionGroup group;
/*    */   private final Option option;
/*    */ 
/*    */   public AlreadySelectedException(OptionGroup group, Option option)
/*    */   {
/* 44 */     this("The option '" + option.getKey() + "' was specified but an option from this group has already been selected: '" + group.getSelected() + "'", group, option);
/*    */   }
/*    */ 
/*    */   public AlreadySelectedException(String message)
/*    */   {
/* 54 */     this(message, null, null);
/*    */   }
/*    */ 
/*    */   private AlreadySelectedException(String message, OptionGroup group, Option option) {
/* 58 */     super(message);
/* 59 */     this.group = group;
/* 60 */     this.option = option;
/*    */   }
/*    */ 
/*    */   public Option getOption()
/*    */   {
/* 70 */     return this.option;
/*    */   }
/*    */ 
/*    */   public OptionGroup getOptionGroup()
/*    */   {
/* 80 */     return this.group;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.AlreadySelectedException
 * JD-Core Version:    0.6.0
 */