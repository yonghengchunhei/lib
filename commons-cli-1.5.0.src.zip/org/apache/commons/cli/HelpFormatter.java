/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class HelpFormatter
/*     */ {
/*     */   public static final int DEFAULT_WIDTH = 74;
/*     */   public static final int DEFAULT_LEFT_PAD = 1;
/*     */   public static final int DEFAULT_DESC_PAD = 3;
/*     */   public static final String DEFAULT_SYNTAX_PREFIX = "usage: ";
/*     */   public static final String DEFAULT_OPT_PREFIX = "-";
/*     */   public static final String DEFAULT_LONG_OPT_PREFIX = "--";
/*     */   public static final String DEFAULT_LONG_OPT_SEPARATOR = " ";
/*     */   public static final String DEFAULT_ARG_NAME = "arg";
/*     */ 
/*     */   @Deprecated
/* 123 */   public int defaultWidth = 74;
/*     */ 
/*     */   @Deprecated
/* 131 */   public int defaultLeftPad = 1;
/*     */ 
/*     */   @Deprecated
/* 139 */   public int defaultDescPad = 3;
/*     */ 
/*     */   @Deprecated
/* 147 */   public String defaultSyntaxPrefix = "usage: ";
/*     */ 
/*     */   @Deprecated
/* 156 */   public String defaultNewLine = System.getProperty("line.separator")
/* 156 */     ;
/*     */ 
/*     */   @Deprecated
/* 163 */   public String defaultOptPrefix = "-";
/*     */ 
/*     */   @Deprecated
/* 171 */   public String defaultLongOptPrefix = "--";
/*     */ 
/*     */   @Deprecated
/* 179 */   public String defaultArgName = "arg";
/*     */ 
/* 187 */   protected Comparator<Option> optionComparator = new OptionComparator(null);
/*     */ 
/* 190 */   private String longOptSeparator = " ";
/*     */ 
/*     */   private void appendOption(StringBuffer buff, Option option, boolean required)
/*     */   {
/* 200 */     if (!required) {
/* 201 */       buff.append("[");
/*     */     }
/*     */ 
/* 204 */     if (option.getOpt() != null)
/* 205 */       buff.append("-").append(option.getOpt());
/*     */     else {
/* 207 */       buff.append("--").append(option.getLongOpt());
/*     */     }
/*     */ 
/* 211 */     if ((option.hasArg()) && ((option.getArgName() == null) || (!option.getArgName().isEmpty()))) {
/* 212 */       buff.append(option.getOpt() == null ? this.longOptSeparator : " ");
/* 213 */       buff.append("<").append(option.getArgName() != null ? option.getArgName() : getArgName()).append(">");
/*     */     }
/*     */ 
/* 217 */     if (!required)
/* 218 */       buff.append("]");
/*     */   }
/*     */ 
/*     */   private void appendOptionGroup(StringBuffer buff, OptionGroup group)
/*     */   {
/* 231 */     if (!group.isRequired()) {
/* 232 */       buff.append("[");
/*     */     }
/*     */ 
/* 235 */     List optList = new ArrayList(group.getOptions());
/* 236 */     if (getOptionComparator() != null) {
/* 237 */       Collections.sort(optList, getOptionComparator());
/*     */     }
/*     */ 
/* 240 */     for (Iterator it = optList.iterator(); it.hasNext(); )
/*     */     {
/* 242 */       appendOption(buff, (Option)it.next(), true);
/*     */ 
/* 244 */       if (it.hasNext()) {
/* 245 */         buff.append(" | ");
/*     */       }
/*     */     }
/*     */ 
/* 249 */     if (!group.isRequired())
/* 250 */       buff.append("]");
/*     */   }
/*     */ 
/*     */   protected String createPadding(int len)
/*     */   {
/* 262 */     char[] padding = new char[len];
/* 263 */     Arrays.fill(padding, ' ');
/*     */ 
/* 265 */     return new String(padding);
/*     */   }
/*     */ 
/*     */   protected int findWrapPos(String text, int width, int startPos)
/*     */   {
/* 280 */     int pos = text.indexOf(10, startPos);
/* 281 */     if ((pos != -1) && (pos <= width)) {
/* 282 */       return pos + 1;
/*     */     }
/*     */ 
/* 285 */     pos = text.indexOf(9, startPos);
/* 286 */     if ((pos != -1) && (pos <= width)) {
/* 287 */       return pos + 1;
/*     */     }
/*     */ 
/* 290 */     if (startPos + width >= text.length()) {
/* 291 */       return -1;
/*     */     }
/*     */ 
/* 295 */     for (pos = startPos + width; pos >= startPos; pos--) {
/* 296 */       char c = text.charAt(pos);
/* 297 */       if ((c == ' ') || (c == '\n') || (c == '\r'))
/*     */       {
/*     */         break;
/*     */       }
/*     */     }
/*     */ 
/* 303 */     if (pos > startPos) {
/* 304 */       return pos;
/*     */     }
/*     */ 
/* 308 */     pos = startPos + width;
/*     */ 
/* 310 */     return pos == text.length() ? -1 : pos;
/*     */   }
/*     */ 
/*     */   public String getArgName()
/*     */   {
/* 319 */     return this.defaultArgName;
/*     */   }
/*     */ 
/*     */   public int getDescPadding()
/*     */   {
/* 328 */     return this.defaultDescPad;
/*     */   }
/*     */ 
/*     */   public int getLeftPadding()
/*     */   {
/* 337 */     return this.defaultLeftPad;
/*     */   }
/*     */ 
/*     */   public String getLongOptPrefix()
/*     */   {
/* 346 */     return this.defaultLongOptPrefix;
/*     */   }
/*     */ 
/*     */   public String getLongOptSeparator()
/*     */   {
/* 356 */     return this.longOptSeparator;
/*     */   }
/*     */ 
/*     */   public String getNewLine()
/*     */   {
/* 365 */     return this.defaultNewLine;
/*     */   }
/*     */ 
/*     */   public Comparator<Option> getOptionComparator()
/*     */   {
/* 376 */     return this.optionComparator;
/*     */   }
/*     */ 
/*     */   public String getOptPrefix()
/*     */   {
/* 385 */     return this.defaultOptPrefix;
/*     */   }
/*     */ 
/*     */   public String getSyntaxPrefix()
/*     */   {
/* 394 */     return this.defaultSyntaxPrefix;
/*     */   }
/*     */ 
/*     */   public int getWidth()
/*     */   {
/* 403 */     return this.defaultWidth;
/*     */   }
/*     */ 
/*     */   public void printHelp(int width, String cmdLineSyntax, String header, Options options, String footer)
/*     */   {
/* 417 */     printHelp(width, cmdLineSyntax, header, options, footer, false);
/*     */   }
/*     */ 
/*     */   public void printHelp(int width, String cmdLineSyntax, String header, Options options, String footer, boolean autoUsage)
/*     */   {
/* 433 */     PrintWriter pw = new PrintWriter(System.out);
/*     */ 
/* 435 */     printHelp(pw, width, cmdLineSyntax, header, options, getLeftPadding(), getDescPadding(), footer, autoUsage);
/* 436 */     pw.flush();
/*     */   }
/*     */ 
/*     */   public void printHelp(PrintWriter pw, int width, String cmdLineSyntax, String header, Options options, int leftPad, int descPad, String footer)
/*     */   {
/* 455 */     printHelp(pw, width, cmdLineSyntax, header, options, leftPad, descPad, footer, false);
/*     */   }
/*     */ 
/*     */   public void printHelp(PrintWriter pw, int width, String cmdLineSyntax, String header, Options options, int leftPad, int descPad, String footer, boolean autoUsage)
/*     */   {
/* 475 */     if ((cmdLineSyntax == null) || (cmdLineSyntax.isEmpty())) {
/* 476 */       throw new IllegalArgumentException("cmdLineSyntax not provided");
/*     */     }
/*     */ 
/* 479 */     if (autoUsage)
/* 480 */       printUsage(pw, width, cmdLineSyntax, options);
/*     */     else {
/* 482 */       printUsage(pw, width, cmdLineSyntax);
/*     */     }
/*     */ 
/* 485 */     if ((header != null) && (!header.isEmpty())) {
/* 486 */       printWrapped(pw, width, header);
/*     */     }
/*     */ 
/* 489 */     printOptions(pw, width, options, leftPad, descPad);
/*     */ 
/* 491 */     if ((footer != null) && (!footer.isEmpty()))
/* 492 */       printWrapped(pw, width, footer);
/*     */   }
/*     */ 
/*     */   public void printHelp(String cmdLineSyntax, Options options)
/*     */   {
/* 504 */     printHelp(getWidth(), cmdLineSyntax, null, options, null, false);
/*     */   }
/*     */ 
/*     */   public void printHelp(String cmdLineSyntax, Options options, boolean autoUsage)
/*     */   {
/* 516 */     printHelp(getWidth(), cmdLineSyntax, null, options, null, autoUsage);
/*     */   }
/*     */ 
/*     */   public void printHelp(String cmdLineSyntax, String header, Options options, String footer)
/*     */   {
/* 529 */     printHelp(cmdLineSyntax, header, options, footer, false);
/*     */   }
/*     */ 
/*     */   public void printHelp(String cmdLineSyntax, String header, Options options, String footer, boolean autoUsage)
/*     */   {
/* 543 */     printHelp(getWidth(), cmdLineSyntax, header, options, footer, autoUsage);
/*     */   }
/*     */ 
/*     */   public void printOptions(PrintWriter pw, int width, Options options, int leftPad, int descPad)
/*     */   {
/* 557 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 559 */     renderOptions(sb, width, options, leftPad, descPad);
/* 560 */     pw.println(sb.toString());
/*     */   }
/*     */ 
/*     */   public void printUsage(PrintWriter pw, int width, String cmdLineSyntax)
/*     */   {
/* 571 */     int argPos = cmdLineSyntax.indexOf(32) + 1;
/*     */ 
/* 573 */     printWrapped(pw, width, getSyntaxPrefix().length() + argPos, new StringBuilder().append(getSyntaxPrefix()).append(cmdLineSyntax).toString());
/*     */   }
/*     */ 
/*     */   public void printUsage(PrintWriter pw, int width, String app, Options options)
/*     */   {
/* 586 */     StringBuffer buff = new StringBuffer(getSyntaxPrefix()).append(app).append(" ");
/*     */ 
/* 589 */     Collection processedGroups = new ArrayList();
/*     */ 
/* 591 */     List optList = new ArrayList(options.getOptions());
/* 592 */     if (getOptionComparator() != null) {
/* 593 */       Collections.sort(optList, getOptionComparator());
/*     */     }
/*     */ 
/* 596 */     for (Iterator it = optList.iterator(); it.hasNext(); )
/*     */     {
/* 598 */       Option option = (Option)it.next();
/*     */ 
/* 601 */       OptionGroup group = options.getOptionGroup(option);
/*     */ 
/* 604 */       if (group != null)
/*     */       {
/* 606 */         if (!processedGroups.contains(group))
/*     */         {
/* 608 */           processedGroups.add(group);
/*     */ 
/* 611 */           appendOptionGroup(buff, group);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 620 */         appendOption(buff, option, option.isRequired());
/*     */       }
/*     */ 
/* 623 */       if (it.hasNext()) {
/* 624 */         buff.append(" ");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 629 */     printWrapped(pw, width, buff.toString().indexOf(32) + 1, buff.toString());
/*     */   }
/*     */ 
/*     */   public void printWrapped(PrintWriter pw, int width, int nextLineTabStop, String text)
/*     */   {
/* 641 */     StringBuffer sb = new StringBuffer(text.length());
/*     */ 
/* 643 */     renderWrappedTextBlock(sb, width, nextLineTabStop, text);
/* 644 */     pw.println(sb.toString());
/*     */   }
/*     */ 
/*     */   public void printWrapped(PrintWriter pw, int width, String text)
/*     */   {
/* 655 */     printWrapped(pw, width, 0, text);
/*     */   }
/*     */ 
/*     */   protected StringBuffer renderOptions(StringBuffer sb, int width, Options options, int leftPad, int descPad)
/*     */   {
/* 670 */     String lpad = createPadding(leftPad);
/* 671 */     String dpad = createPadding(descPad);
/*     */ 
/* 677 */     int max = 0;
/* 678 */     List prefixList = new ArrayList();
/*     */ 
/* 680 */     List optList = options.helpOptions();
/*     */ 
/* 682 */     if (getOptionComparator() != null) {
/* 683 */       Collections.sort(optList, getOptionComparator());
/*     */     }
/*     */ 
/* 686 */     for (Option option : optList) {
/* 687 */       StringBuffer optBuf = new StringBuffer();
/*     */ 
/* 689 */       if (option.getOpt() == null) {
/* 690 */         optBuf.append(lpad).append("   ").append(getLongOptPrefix()).append(option.getLongOpt());
/*     */       } else {
/* 692 */         optBuf.append(lpad).append(getOptPrefix()).append(option.getOpt());
/*     */ 
/* 694 */         if (option.hasLongOpt()) {
/* 695 */           optBuf.append(',').append(getLongOptPrefix()).append(option.getLongOpt());
/*     */         }
/*     */       }
/*     */ 
/* 699 */       if (option.hasArg()) {
/* 700 */         String argName = option.getArgName();
/* 701 */         if ((argName != null) && (argName.isEmpty()))
/*     */         {
/* 703 */           optBuf.append(' ');
/*     */         } else {
/* 705 */           optBuf.append(option.hasLongOpt() ? this.longOptSeparator : " ");
/* 706 */           optBuf.append("<").append(argName != null ? option.getArgName() : getArgName()).append(">");
/*     */         }
/*     */       }
/*     */ 
/* 710 */       prefixList.add(optBuf);
/* 711 */       max = optBuf.length() > max ? optBuf.length() : max;
/*     */     }
/*     */ 
/* 714 */     int x = 0;
/*     */ 
/* 716 */     for (Iterator it = optList.iterator(); it.hasNext(); ) {
/* 717 */       Option option = (Option)it.next();
/* 718 */       StringBuilder optBuf = new StringBuilder(((StringBuffer)prefixList.get(x++)).toString());
/*     */ 
/* 720 */       if (optBuf.length() < max) {
/* 721 */         optBuf.append(createPadding(max - optBuf.length()));
/*     */       }
/*     */ 
/* 724 */       optBuf.append(dpad);
/*     */ 
/* 726 */       int nextLineTabStop = max + descPad;
/*     */ 
/* 728 */       if (option.getDescription() != null) {
/* 729 */         optBuf.append(option.getDescription());
/*     */       }
/*     */ 
/* 732 */       renderWrappedText(sb, width, nextLineTabStop, optBuf.toString());
/*     */ 
/* 734 */       if (it.hasNext()) {
/* 735 */         sb.append(getNewLine());
/*     */       }
/*     */     }
/*     */ 
/* 739 */     return sb;
/*     */   }
/*     */ 
/*     */   protected StringBuffer renderWrappedText(StringBuffer sb, int width, int nextLineTabStop, String text)
/*     */   {
/* 753 */     int pos = findWrapPos(text, width, 0);
/*     */ 
/* 755 */     if (pos == -1) {
/* 756 */       sb.append(rtrim(text));
/*     */ 
/* 758 */       return sb;
/*     */     }
/* 760 */     sb.append(rtrim(text.substring(0, pos))).append(getNewLine());
/*     */ 
/* 762 */     if (nextLineTabStop >= width)
/*     */     {
/* 764 */       nextLineTabStop = 1;
/*     */     }
/*     */ 
/* 768 */     String padding = createPadding(nextLineTabStop);
/*     */     while (true)
/*     */     {
/* 771 */       text = new StringBuilder().append(padding).append(text.substring(pos).trim()).toString();
/* 772 */       pos = findWrapPos(text, width, 0);
/*     */ 
/* 774 */       if (pos == -1) {
/* 775 */         sb.append(text);
/*     */ 
/* 777 */         return sb;
/*     */       }
/*     */ 
/* 780 */       if ((text.length() > width) && (pos == nextLineTabStop - 1)) {
/* 781 */         pos = width;
/*     */       }
/*     */ 
/* 784 */       sb.append(rtrim(text.substring(0, pos))).append(getNewLine());
/*     */     }
/*     */   }
/*     */ 
/*     */   private Appendable renderWrappedTextBlock(StringBuffer sb, int width, int nextLineTabStop, String text)
/*     */   {
/*     */     try
/*     */     {
/* 799 */       BufferedReader in = new BufferedReader(new StringReader(text));
/*     */ 
/* 801 */       boolean firstLine = true;
/*     */       String line;
/* 802 */       while ((line = in.readLine()) != null) {
/* 803 */         if (!firstLine)
/* 804 */           sb.append(getNewLine());
/*     */         else {
/* 806 */           firstLine = false;
/*     */         }
/* 808 */         renderWrappedText(sb, width, nextLineTabStop, line);
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/*     */     }
/* 814 */     return sb;
/*     */   }
/*     */ 
/*     */   protected String rtrim(String s)
/*     */   {
/* 825 */     if ((s == null) || (s.isEmpty())) {
/* 826 */       return s;
/*     */     }
/*     */ 
/* 829 */     int pos = s.length();
/*     */ 
/* 831 */     while ((pos > 0) && (Character.isWhitespace(s.charAt(pos - 1)))) {
/* 832 */       pos--;
/*     */     }
/*     */ 
/* 835 */     return s.substring(0, pos);
/*     */   }
/*     */ 
/*     */   public void setArgName(String name)
/*     */   {
/* 844 */     this.defaultArgName = name;
/*     */   }
/*     */ 
/*     */   public void setDescPadding(int padding)
/*     */   {
/* 853 */     this.defaultDescPad = padding;
/*     */   }
/*     */ 
/*     */   public void setLeftPadding(int padding)
/*     */   {
/* 862 */     this.defaultLeftPad = padding;
/*     */   }
/*     */ 
/*     */   public void setLongOptPrefix(String prefix)
/*     */   {
/* 871 */     this.defaultLongOptPrefix = prefix;
/*     */   }
/*     */ 
/*     */   public void setLongOptSeparator(String longOptSeparator)
/*     */   {
/* 882 */     this.longOptSeparator = longOptSeparator;
/*     */   }
/*     */ 
/*     */   public void setNewLine(String newline)
/*     */   {
/* 891 */     this.defaultNewLine = newline;
/*     */   }
/*     */ 
/*     */   public void setOptionComparator(Comparator<Option> comparator)
/*     */   {
/* 902 */     this.optionComparator = comparator;
/*     */   }
/*     */ 
/*     */   public void setOptPrefix(String prefix)
/*     */   {
/* 911 */     this.defaultOptPrefix = prefix;
/*     */   }
/*     */ 
/*     */   public void setSyntaxPrefix(String prefix)
/*     */   {
/* 920 */     this.defaultSyntaxPrefix = prefix;
/*     */   }
/*     */ 
/*     */   public void setWidth(int width)
/*     */   {
/* 929 */     this.defaultWidth = width;
/*     */   }
/*     */ 
/*     */   private static class OptionComparator
/*     */     implements Comparator<Option>, Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 5305467873966684014L;
/*     */ 
/*     */     public int compare(Option opt1, Option opt2)
/*     */     {
/*  86 */       return opt1.getKey().compareToIgnoreCase(opt2.getKey());
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.HelpFormatter
 * JD-Core Version:    0.6.0
 */