/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public class Option
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   public static final int UNINITIALIZED = -1;
/*     */   public static final int UNLIMITED_VALUES = -2;
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final String option;
/*     */   private String longOption;
/*     */   private String argName;
/*     */   private String description;
/*     */   private boolean required;
/*     */   private boolean optionalArg;
/* 322 */   private int argCount = -1;
/*     */ 
/* 325 */   private Class<?> type = String.class;
/*     */ 
/* 328 */   private List<String> values = new ArrayList();
/*     */   private char valuesep;
/*     */ 
/*     */   public static Builder builder()
/*     */   {
/* 288 */     return builder(null);
/*     */   }
/*     */ 
/*     */   public static Builder builder(String option)
/*     */   {
/* 300 */     return new Builder(option, null);
/*     */   }
/*     */ 
/*     */   private Option(Builder builder)
/*     */   {
/* 339 */     this.argName = builder.argName;
/* 340 */     this.description = builder.description;
/* 341 */     this.longOption = builder.longOption;
/* 342 */     this.argCount = builder.argCount;
/* 343 */     this.option = builder.option;
/* 344 */     this.optionalArg = builder.optionalArg;
/* 345 */     this.required = builder.required;
/* 346 */     this.type = builder.type;
/* 347 */     this.valuesep = builder.valueSeparator;
/*     */   }
/*     */ 
/*     */   public Option(String option, boolean hasArg, String description)
/*     */     throws IllegalArgumentException
/*     */   {
/* 360 */     this(option, null, hasArg, description);
/*     */   }
/*     */ 
/*     */   public Option(String option, String description)
/*     */     throws IllegalArgumentException
/*     */   {
/* 372 */     this(option, null, false, description);
/*     */   }
/*     */ 
/*     */   public Option(String option, String longOption, boolean hasArg, String description)
/*     */     throws IllegalArgumentException
/*     */   {
/* 387 */     this.option = OptionValidator.validate(option);
/* 388 */     this.longOption = longOption;
/*     */ 
/* 391 */     if (hasArg) {
/* 392 */       this.argCount = 1;
/*     */     }
/*     */ 
/* 395 */     this.description = description;
/*     */   }
/*     */ 
/*     */   boolean acceptsArg()
/*     */   {
/* 405 */     return ((hasArg()) || (hasArgs()) || (hasOptionalArg())) && ((this.argCount <= 0) || (this.values.size() < this.argCount));
/*     */   }
/*     */ 
/*     */   private void add(String value)
/*     */   {
/* 417 */     if (!acceptsArg()) {
/* 418 */       throw new RuntimeException("Cannot add value, list full.");
/*     */     }
/*     */ 
/* 422 */     this.values.add(value);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean addValue(String value)
/*     */   {
/* 436 */     throw new UnsupportedOperationException("The addValue method is not intended for client use. Subclasses should use the addValueForProcessing method instead. ");
/*     */   }
/*     */ 
/*     */   void addValueForProcessing(String value)
/*     */   {
/* 446 */     if (this.argCount == -1) {
/* 447 */       throw new RuntimeException("NO_ARGS_ALLOWED");
/*     */     }
/* 449 */     processValue(value);
/*     */   }
/*     */ 
/*     */   void clearValues()
/*     */   {
/* 459 */     this.values.clear();
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 474 */       Option option = (Option)super.clone();
/* 475 */       option.values = new ArrayList(this.values);
/* 476 */       return option; } catch (CloneNotSupportedException cnse) {
/*     */     }
/* 478 */     throw new RuntimeException(new StringBuilder().append("A CloneNotSupportedException was thrown: ").append(cnse.getMessage()).toString());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 484 */     if (this == obj) {
/* 485 */       return true;
/*     */     }
/* 487 */     if (!(obj instanceof Option)) {
/* 488 */       return false;
/*     */     }
/* 490 */     Option other = (Option)obj;
/* 491 */     return (Objects.equals(this.longOption, other.longOption)) && (Objects.equals(this.option, other.option));
/*     */   }
/*     */ 
/*     */   public String getArgName()
/*     */   {
/* 500 */     return this.argName;
/*     */   }
/*     */ 
/*     */   public int getArgs()
/*     */   {
/* 517 */     return this.argCount;
/*     */   }
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 526 */     return this.description;
/*     */   }
/*     */ 
/*     */   public int getId()
/*     */   {
/* 536 */     return getKey().charAt(0);
/*     */   }
/*     */ 
/*     */   String getKey()
/*     */   {
/* 546 */     return this.option == null ? this.longOption : this.option;
/*     */   }
/*     */ 
/*     */   public String getLongOpt()
/*     */   {
/* 555 */     return this.longOption;
/*     */   }
/*     */ 
/*     */   public String getOpt()
/*     */   {
/* 567 */     return this.option;
/*     */   }
/*     */ 
/*     */   public Object getType()
/*     */   {
/* 576 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 585 */     return hasNoValues() ? null : (String)this.values.get(0);
/*     */   }
/*     */ 
/*     */   public String getValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 598 */     return hasNoValues() ? null : (String)this.values.get(index);
/*     */   }
/*     */ 
/*     */   public String getValue(String defaultValue)
/*     */   {
/* 609 */     String value = getValue();
/*     */ 
/* 611 */     return value != null ? value : defaultValue;
/*     */   }
/*     */ 
/*     */   public String[] getValues()
/*     */   {
/* 620 */     return hasNoValues() ? null : (String[])this.values.toArray(new String[this.values.size()]);
/*     */   }
/*     */ 
/*     */   public char getValueSeparator()
/*     */   {
/* 629 */     return this.valuesep;
/*     */   }
/*     */ 
/*     */   public List<String> getValuesList()
/*     */   {
/* 638 */     return this.values;
/*     */   }
/*     */ 
/*     */   public boolean hasArg()
/*     */   {
/* 647 */     return (this.argCount > 0) || (this.argCount == -2);
/*     */   }
/*     */ 
/*     */   public boolean hasArgName()
/*     */   {
/* 656 */     return (this.argName != null) && (!this.argName.isEmpty());
/*     */   }
/*     */ 
/*     */   public boolean hasArgs()
/*     */   {
/* 665 */     return (this.argCount > 1) || (this.argCount == -2);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 670 */     return Objects.hash(new Object[] { this.longOption, this.option });
/*     */   }
/*     */ 
/*     */   public boolean hasLongOpt()
/*     */   {
/* 679 */     return this.longOption != null;
/*     */   }
/*     */ 
/*     */   private boolean hasNoValues()
/*     */   {
/* 688 */     return this.values.isEmpty();
/*     */   }
/*     */ 
/*     */   public boolean hasOptionalArg()
/*     */   {
/* 695 */     return this.optionalArg;
/*     */   }
/*     */ 
/*     */   public boolean hasValueSeparator()
/*     */   {
/* 705 */     return this.valuesep > 0;
/*     */   }
/*     */ 
/*     */   public boolean isRequired()
/*     */   {
/* 714 */     return this.required;
/*     */   }
/*     */ 
/*     */   private void processValue(String value)
/*     */   {
/* 728 */     if (hasValueSeparator())
/*     */     {
/* 730 */       char sep = getValueSeparator();
/*     */ 
/* 733 */       int index = value.indexOf(sep);
/*     */ 
/* 736 */       while (index != -1)
/*     */       {
/* 738 */         if (this.values.size() == this.argCount - 1)
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 743 */         add(value.substring(0, index));
/*     */ 
/* 746 */         value = value.substring(index + 1);
/*     */ 
/* 749 */         index = value.indexOf(sep);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 754 */     add(value);
/*     */   }
/*     */ 
/*     */   boolean requiresArg()
/*     */   {
/* 764 */     if (this.optionalArg) {
/* 765 */       return false;
/*     */     }
/* 767 */     if (this.argCount == -2) {
/* 768 */       return this.values.isEmpty();
/*     */     }
/* 770 */     return acceptsArg();
/*     */   }
/*     */ 
/*     */   public void setArgName(String argName)
/*     */   {
/* 779 */     this.argName = argName;
/*     */   }
/*     */ 
/*     */   public void setArgs(int num)
/*     */   {
/* 788 */     this.argCount = num;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 798 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public void setLongOpt(String longOpt)
/*     */   {
/* 807 */     this.longOption = longOpt;
/*     */   }
/*     */ 
/*     */   public void setOptionalArg(boolean optionalArg)
/*     */   {
/* 816 */     this.optionalArg = optionalArg;
/*     */   }
/*     */ 
/*     */   public void setRequired(boolean required)
/*     */   {
/* 825 */     this.required = required;
/*     */   }
/*     */ 
/*     */   public void setType(Class<?> type)
/*     */   {
/* 835 */     this.type = type;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setType(Object type)
/*     */   {
/* 850 */     setType((Class)type);
/*     */   }
/*     */ 
/*     */   public void setValueSeparator(char sep)
/*     */   {
/* 859 */     this.valuesep = sep;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 869 */     StringBuilder buf = new StringBuilder().append("[ option: ");
/*     */ 
/* 871 */     buf.append(this.option);
/*     */ 
/* 873 */     if (this.longOption != null) {
/* 874 */       buf.append(" ").append(this.longOption);
/*     */     }
/*     */ 
/* 877 */     buf.append(" ");
/*     */ 
/* 879 */     if (hasArgs())
/* 880 */       buf.append("[ARG...]");
/* 881 */     else if (hasArg()) {
/* 882 */       buf.append(" [ARG]");
/*     */     }
/*     */ 
/* 885 */     buf.append(" :: ").append(this.description);
/*     */ 
/* 887 */     if (this.type != null) {
/* 888 */       buf.append(" :: ").append(this.type);
/*     */     }
/*     */ 
/* 891 */     buf.append(" ]");
/*     */ 
/* 893 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*     */     private String option;
/*     */     private String description;
/*     */     private String longOption;
/*     */     private String argName;
/*     */     private boolean required;
/*     */     private boolean optionalArg;
/*  76 */     private int argCount = -1;
/*     */ 
/*  79 */     private Class<?> type = String.class;
/*     */     private char valueSeparator;
/*     */ 
/*     */     private Builder(String option)
/*     */       throws IllegalArgumentException
/*     */     {
/*  91 */       option(option);
/*     */     }
/*     */ 
/*     */     public Builder argName(String argName)
/*     */     {
/* 101 */       this.argName = argName;
/* 102 */       return this;
/*     */     }
/*     */ 
/*     */     public Option build()
/*     */     {
/* 112 */       if ((this.option == null) && (this.longOption == null)) {
/* 113 */         throw new IllegalArgumentException("Either opt or longOpt must be specified");
/*     */       }
/* 115 */       return new Option(this, null);
/*     */     }
/*     */ 
/*     */     public Builder desc(String description)
/*     */     {
/* 125 */       this.description = description;
/* 126 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder hasArg()
/*     */     {
/* 135 */       return hasArg(true);
/*     */     }
/*     */ 
/*     */     public Builder hasArg(boolean hasArg)
/*     */     {
/* 146 */       this.argCount = (hasArg ? 1 : -1);
/* 147 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder hasArgs()
/*     */     {
/* 156 */       this.argCount = -2;
/* 157 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder longOpt(String longOpt)
/*     */     {
/* 167 */       this.longOption = longOpt;
/* 168 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder numberOfArgs(int numberOfArgs)
/*     */     {
/* 178 */       this.argCount = numberOfArgs;
/* 179 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder option(String option)
/*     */       throws IllegalArgumentException
/*     */     {
/* 191 */       this.option = OptionValidator.validate(option);
/* 192 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder optionalArg(boolean isOptional)
/*     */     {
/* 202 */       this.optionalArg = isOptional;
/* 203 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder required()
/*     */     {
/* 212 */       return required(true);
/*     */     }
/*     */ 
/*     */     public Builder required(boolean required)
/*     */     {
/* 222 */       this.required = required;
/* 223 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder type(Class<?> type)
/*     */     {
/* 233 */       this.type = type;
/* 234 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder valueSeparator()
/*     */     {
/* 243 */       return valueSeparator('=');
/*     */     }
/*     */ 
/*     */     public Builder valueSeparator(char sep)
/*     */     {
/* 267 */       this.valueSeparator = sep;
/* 268 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.Option
 * JD-Core Version:    0.6.0
 */