/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ @Deprecated
/*     */ public class PosixParser extends Parser
/*     */ {
/*  34 */   private final List<String> tokens = new ArrayList();
/*     */   private boolean eatTheRest;
/*     */   private Option currentOption;
/*     */   private Options options;
/*     */ 
/*     */   protected void burstToken(String token, boolean stopAtNonOption)
/*     */   {
/*  66 */     for (int i = 1; i < token.length(); i++) {
/*  67 */       String ch = String.valueOf(token.charAt(i));
/*     */ 
/*  69 */       if (!this.options.hasOption(ch)) {
/*  70 */         if (stopAtNonOption) {
/*  71 */           processNonOptionToken(token.substring(i), true); break;
/*     */         }
/*  73 */         this.tokens.add(token);
/*     */ 
/*  75 */         break;
/*     */       }
/*  77 */       this.tokens.add("-" + ch);
/*  78 */       this.currentOption = this.options.getOption(ch);
/*     */ 
/*  80 */       if ((this.currentOption.hasArg()) && (token.length() != i + 1)) {
/*  81 */         this.tokens.add(token.substring(i + 1));
/*     */ 
/*  83 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption)
/*     */     throws ParseException
/*     */   {
/* 120 */     init();
/* 121 */     this.options = options;
/*     */ 
/* 124 */     Iterator iter = Arrays.asList(arguments).iterator();
/*     */ 
/* 127 */     while (iter.hasNext())
/*     */     {
/* 129 */       String token = (String)iter.next();
/*     */ 
/* 132 */       if (("-".equals(token)) || ("--".equals(token))) {
/* 133 */         this.tokens.add(token);
/*     */       }
/* 137 */       else if (token.startsWith("--")) {
/* 138 */         int pos = token.indexOf(61);
/* 139 */         String opt = pos == -1 ? token : token.substring(0, pos);
/*     */ 
/* 141 */         List matchingOpts = options.getMatchingOptions(opt);
/*     */ 
/* 143 */         if (matchingOpts.isEmpty()) {
/* 144 */           processNonOptionToken(token, stopAtNonOption); } else {
/* 145 */           if (matchingOpts.size() > 1) {
/* 146 */             throw new AmbiguousOptionException(opt, matchingOpts);
/*     */           }
/* 148 */           this.currentOption = options.getOption((String)matchingOpts.get(0));
/*     */ 
/* 150 */           this.tokens.add("--" + this.currentOption.getLongOpt());
/* 151 */           if (pos != -1) {
/* 152 */             this.tokens.add(token.substring(pos + 1));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 157 */       else if (token.startsWith("-")) {
/* 158 */         if ((token.length() == 2) || (options.hasOption(token))) {
/* 159 */           processOptionToken(token, stopAtNonOption);
/* 160 */         } else if (!options.getMatchingOptions(token).isEmpty()) {
/* 161 */           List matchingOpts = options.getMatchingOptions(token);
/* 162 */           if (matchingOpts.size() > 1) {
/* 163 */             throw new AmbiguousOptionException(token, matchingOpts);
/*     */           }
/* 165 */           Option opt = options.getOption((String)matchingOpts.get(0));
/* 166 */           processOptionToken("-" + opt.getLongOpt(), stopAtNonOption);
/*     */         }
/*     */         else
/*     */         {
/* 170 */           burstToken(token, stopAtNonOption);
/*     */         }
/*     */       } else {
/* 173 */         processNonOptionToken(token, stopAtNonOption);
/*     */       }
/*     */ 
/* 176 */       gobble(iter);
/*     */     }
/*     */ 
/* 179 */     return (String[])this.tokens.toArray(Util.EMPTY_STRING_ARRAY);
/*     */   }
/*     */ 
/*     */   private void gobble(Iterator<String> iter)
/*     */   {
/* 188 */     if (this.eatTheRest)
/* 189 */       while (iter.hasNext())
/* 190 */         this.tokens.add(iter.next());
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/* 200 */     this.eatTheRest = false;
/* 201 */     this.tokens.clear();
/*     */   }
/*     */ 
/*     */   private void processNonOptionToken(String value, boolean stopAtNonOption)
/*     */   {
/* 211 */     if ((stopAtNonOption) && ((this.currentOption == null) || (!this.currentOption.hasArg()))) {
/* 212 */       this.eatTheRest = true;
/* 213 */       this.tokens.add("--");
/*     */     }
/*     */ 
/* 216 */     this.tokens.add(value);
/*     */   }
/*     */ 
/*     */   private void processOptionToken(String token, boolean stopAtNonOption)
/*     */   {
/* 233 */     if ((stopAtNonOption) && (!this.options.hasOption(token))) {
/* 234 */       this.eatTheRest = true;
/*     */     }
/*     */ 
/* 237 */     if (this.options.hasOption(token)) {
/* 238 */       this.currentOption = this.options.getOption(token);
/*     */     }
/*     */ 
/* 241 */     this.tokens.add(token);
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.PosixParser
 * JD-Core Version:    0.6.0
 */