/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ 
/*    */ public class AmbiguousOptionException extends UnrecognizedOptionException
/*    */ {
/*    */   private static final long serialVersionUID = 5829816121277947229L;
/*    */   private final Collection<String> matchingOptions;
/*    */ 
/*    */   private static String createMessage(String option, Collection<String> matchingOptions)
/*    */   {
/* 42 */     StringBuilder buf = new StringBuilder("Ambiguous option: '");
/* 43 */     buf.append(option);
/* 44 */     buf.append("'  (could be: ");
/*    */ 
/* 46 */     Iterator it = matchingOptions.iterator();
/* 47 */     while (it.hasNext()) {
/* 48 */       buf.append("'");
/* 49 */       buf.append((String)it.next());
/* 50 */       buf.append("'");
/* 51 */       if (it.hasNext()) {
/* 52 */         buf.append(", ");
/*    */       }
/*    */     }
/* 55 */     buf.append(")");
/*    */ 
/* 57 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   public AmbiguousOptionException(String option, Collection<String> matchingOptions)
/*    */   {
/* 70 */     super(createMessage(option, matchingOptions), option);
/* 71 */     this.matchingOptions = matchingOptions;
/*    */   }
/*    */ 
/*    */   public Collection<String> getMatchingOptions()
/*    */   {
/* 80 */     return this.matchingOptions;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.AmbiguousOptionException
 * JD-Core Version:    0.6.0
 */