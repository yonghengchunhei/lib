/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ @Deprecated
/*    */ public class BasicParser extends Parser
/*    */ {
/*    */   protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption)
/*    */   {
/* 47 */     return arguments;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.BasicParser
 * JD-Core Version:    0.6.0
 */