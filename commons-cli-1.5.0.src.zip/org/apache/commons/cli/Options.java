/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Options
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  44 */   private final Map<String, Option> shortOpts = new LinkedHashMap();
/*     */ 
/*  47 */   private final Map<String, Option> longOpts = new LinkedHashMap();
/*     */ 
/*  52 */   private final List<Object> requiredOpts = new ArrayList();
/*     */ 
/*  55 */   private final Map<String, OptionGroup> optionGroups = new LinkedHashMap();
/*     */ 
/*     */   public Options addOption(Option opt)
/*     */   {
/*  64 */     String key = opt.getKey();
/*     */ 
/*  67 */     if (opt.hasLongOpt()) {
/*  68 */       this.longOpts.put(opt.getLongOpt(), opt);
/*     */     }
/*     */ 
/*  72 */     if (opt.isRequired()) {
/*  73 */       if (this.requiredOpts.contains(key)) {
/*  74 */         this.requiredOpts.remove(this.requiredOpts.indexOf(key));
/*     */       }
/*  76 */       this.requiredOpts.add(key);
/*     */     }
/*     */ 
/*  79 */     this.shortOpts.put(key, opt);
/*     */ 
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */   public Options addOption(String opt, boolean hasArg, String description)
/*     */   {
/*  97 */     addOption(opt, null, hasArg, description);
/*  98 */     return this;
/*     */   }
/*     */ 
/*     */   public Options addOption(String opt, String description)
/*     */   {
/* 114 */     addOption(opt, null, false, description);
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   public Options addOption(String opt, String longOpt, boolean hasArg, String description)
/*     */   {
/* 132 */     addOption(new Option(opt, longOpt, hasArg, description));
/* 133 */     return this;
/*     */   }
/*     */ 
/*     */   public Options addOptionGroup(OptionGroup group)
/*     */   {
/* 143 */     if (group.isRequired()) {
/* 144 */       this.requiredOpts.add(group);
/*     */     }
/*     */ 
/* 147 */     for (Option option : group.getOptions())
/*     */     {
/* 151 */       option.setRequired(false);
/* 152 */       addOption(option);
/*     */ 
/* 154 */       this.optionGroups.put(option.getKey(), group);
/*     */     }
/*     */ 
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   public Options addRequiredOption(String opt, String longOpt, boolean hasArg, String description)
/*     */   {
/* 183 */     Option option = new Option(opt, longOpt, hasArg, description);
/* 184 */     option.setRequired(true);
/* 185 */     addOption(option);
/* 186 */     return this;
/*     */   }
/*     */ 
/*     */   public List<String> getMatchingOptions(String opt)
/*     */   {
/* 197 */     opt = Util.stripLeadingHyphens(opt);
/*     */ 
/* 199 */     List matchingOpts = new ArrayList();
/*     */ 
/* 202 */     if (this.longOpts.containsKey(opt)) {
/* 203 */       return Collections.singletonList(opt);
/*     */     }
/*     */ 
/* 206 */     for (String longOpt : this.longOpts.keySet()) {
/* 207 */       if (longOpt.startsWith(opt)) {
/* 208 */         matchingOpts.add(longOpt);
/*     */       }
/*     */     }
/*     */ 
/* 212 */     return matchingOpts;
/*     */   }
/*     */ 
/*     */   public Option getOption(String opt)
/*     */   {
/* 226 */     opt = Util.stripLeadingHyphens(opt);
/*     */ 
/* 228 */     if (this.shortOpts.containsKey(opt)) {
/* 229 */       return (Option)this.shortOpts.get(opt);
/*     */     }
/*     */ 
/* 232 */     return (Option)this.longOpts.get(opt);
/*     */   }
/*     */ 
/*     */   public OptionGroup getOptionGroup(Option opt)
/*     */   {
/* 242 */     return (OptionGroup)this.optionGroups.get(opt.getKey());
/*     */   }
/*     */ 
/*     */   Collection<OptionGroup> getOptionGroups()
/*     */   {
/* 251 */     return new HashSet(this.optionGroups.values());
/*     */   }
/*     */ 
/*     */   public Collection<Option> getOptions()
/*     */   {
/* 260 */     return Collections.unmodifiableCollection(helpOptions());
/*     */   }
/*     */ 
/*     */   public List getRequiredOptions()
/*     */   {
/* 269 */     return Collections.unmodifiableList(this.requiredOpts);
/*     */   }
/*     */ 
/*     */   public boolean hasLongOption(String opt)
/*     */   {
/* 280 */     opt = Util.stripLeadingHyphens(opt);
/*     */ 
/* 282 */     return this.longOpts.containsKey(opt);
/*     */   }
/*     */ 
/*     */   public boolean hasOption(String opt)
/*     */   {
/* 292 */     opt = Util.stripLeadingHyphens(opt);
/*     */ 
/* 294 */     return (this.shortOpts.containsKey(opt)) || (this.longOpts.containsKey(opt));
/*     */   }
/*     */ 
/*     */   public boolean hasShortOption(String opt)
/*     */   {
/* 305 */     opt = Util.stripLeadingHyphens(opt);
/*     */ 
/* 307 */     return this.shortOpts.containsKey(opt);
/*     */   }
/*     */ 
/*     */   List<Option> helpOptions()
/*     */   {
/* 316 */     return new ArrayList(this.shortOpts.values());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 326 */     StringBuilder buf = new StringBuilder();
/*     */ 
/* 328 */     buf.append("[ Options: [ short ");
/* 329 */     buf.append(this.shortOpts.toString());
/* 330 */     buf.append(" ] [ long ");
/* 331 */     buf.append(this.longOpts);
/* 332 */     buf.append(" ]");
/*     */ 
/* 334 */     return buf.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.Options
 * JD-Core Version:    0.6.0
 */