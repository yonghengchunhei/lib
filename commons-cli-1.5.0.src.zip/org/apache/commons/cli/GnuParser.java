/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ @Deprecated
/*    */ public class GnuParser extends Parser
/*    */ {
/*    */   protected String[] flatten(Options options, String[] arguments, boolean stopAtNonOption)
/*    */   {
/* 47 */     List tokens = new ArrayList();
/*    */ 
/* 49 */     boolean eatTheRest = false;
/*    */ 
/* 51 */     for (int i = 0; i < arguments.length; i++) {
/* 52 */       String arg = arguments[i];
/*    */ 
/* 54 */       if ("--".equals(arg)) {
/* 55 */         eatTheRest = true;
/* 56 */         tokens.add("--");
/* 57 */       } else if ("-".equals(arg)) {
/* 58 */         tokens.add("-");
/* 59 */       } else if (arg.startsWith("-")) {
/* 60 */         String opt = Util.stripLeadingHyphens(arg);
/*    */ 
/* 62 */         if (options.hasOption(opt)) {
/* 63 */           tokens.add(arg);
/* 64 */         } else if ((opt.indexOf('=') != -1) && (options.hasOption(opt.substring(0, opt.indexOf('=')))))
/*    */         {
/* 66 */           tokens.add(arg.substring(0, arg.indexOf('=')));
/* 67 */           tokens.add(arg.substring(arg.indexOf('=') + 1));
/* 68 */         } else if (options.hasOption(arg.substring(0, 2)))
/*    */         {
/* 70 */           tokens.add(arg.substring(0, 2));
/* 71 */           tokens.add(arg.substring(2));
/*    */         } else {
/* 73 */           eatTheRest = stopAtNonOption;
/* 74 */           tokens.add(arg);
/*    */         }
/*    */       } else {
/* 77 */         tokens.add(arg);
/*    */       }
/*    */ 
/* 80 */       if (eatTheRest) {
/* 81 */         for (i++; i < arguments.length; i++) {
/* 82 */           tokens.add(arguments[i]);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 87 */     return (String[])tokens.toArray(Util.EMPTY_STRING_ARRAY);
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.GnuParser
 * JD-Core Version:    0.6.0
 */