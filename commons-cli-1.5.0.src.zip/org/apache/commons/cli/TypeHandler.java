/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class TypeHandler
/*     */ {
/*     */   public static Class<?> createClass(String classname)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*  41 */       return Class.forName(classname); } catch (ClassNotFoundException e) {
/*     */     }
/*  43 */     throw new ParseException("Unable to find the class: " + classname);
/*     */   }
/*     */ 
/*     */   public static Date createDate(String str)
/*     */   {
/*  57 */     throw new UnsupportedOperationException("Not yet implemented");
/*     */   }
/*     */ 
/*     */   public static File createFile(String str)
/*     */   {
/*  67 */     return new File(str);
/*     */   }
/*     */ 
/*     */   public static File[] createFiles(String str)
/*     */   {
/*  82 */     throw new UnsupportedOperationException("Not yet implemented");
/*     */   }
/*     */ 
/*     */   public static Number createNumber(String str)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       if (str.indexOf('.') != -1) {
/*  95 */         return Double.valueOf(str);
/*     */       }
/*  97 */       return Long.valueOf(str); } catch (NumberFormatException e) {
/*     */     }
/*  99 */     throw new ParseException(e.getMessage());
/*     */   }
/*     */ 
/*     */   public static Object createObject(String classname)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 114 */       cl = Class.forName(classname);
/*     */     }
/*     */     catch (ClassNotFoundException cnfe)
/*     */     {
/*     */       Class cl;
/* 116 */       throw new ParseException("Unable to find the class: " + classname);
/*     */     }
/*     */     try
/*     */     {
/*     */       Class cl;
/* 120 */       return cl.newInstance(); } catch (Exception e) {
/*     */     }
/* 122 */     throw new ParseException(e.getClass().getName() + "; Unable to create an instance of: " + classname);
/*     */   }
/*     */ 
/*     */   public static URL createURL(String str)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 135 */       return new URL(str); } catch (MalformedURLException e) {
/*     */     }
/* 137 */     throw new ParseException("Unable to parse the URL: " + str);
/*     */   }
/*     */ 
/*     */   public static <T> T createValue(String str, Class<T> clazz)
/*     */     throws ParseException
/*     */   {
/* 152 */     if (PatternOptionBuilder.STRING_VALUE == clazz) {
/* 153 */       return str;
/*     */     }
/* 155 */     if (PatternOptionBuilder.OBJECT_VALUE == clazz) {
/* 156 */       return createObject(str);
/*     */     }
/* 158 */     if (PatternOptionBuilder.NUMBER_VALUE == clazz) {
/* 159 */       return createNumber(str);
/*     */     }
/* 161 */     if (PatternOptionBuilder.DATE_VALUE == clazz) {
/* 162 */       return createDate(str);
/*     */     }
/* 164 */     if (PatternOptionBuilder.CLASS_VALUE == clazz) {
/* 165 */       return createClass(str);
/*     */     }
/* 167 */     if (PatternOptionBuilder.FILE_VALUE == clazz) {
/* 168 */       return createFile(str);
/*     */     }
/* 170 */     if (PatternOptionBuilder.EXISTING_FILE_VALUE == clazz) {
/* 171 */       return openFile(str);
/*     */     }
/* 173 */     if (PatternOptionBuilder.FILES_VALUE == clazz) {
/* 174 */       return createFiles(str);
/*     */     }
/* 176 */     if (PatternOptionBuilder.URL_VALUE == clazz) {
/* 177 */       return createURL(str);
/*     */     }
/* 179 */     throw new ParseException("Unable to handle the class: " + clazz);
/*     */   }
/*     */ 
/*     */   public static Object createValue(String str, Object obj)
/*     */     throws ParseException
/*     */   {
/* 191 */     return createValue(str, (Class)obj);
/*     */   }
/*     */ 
/*     */   public static FileInputStream openFile(String str)
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/* 203 */       return new FileInputStream(str); } catch (FileNotFoundException e) {
/*     */     }
/* 205 */     throw new ParseException("Unable to find file: " + str);
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.TypeHandler
 * JD-Core Version:    0.6.0
 */