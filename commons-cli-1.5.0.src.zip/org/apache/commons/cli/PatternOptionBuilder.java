/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class PatternOptionBuilder
/*     */ {
/*  76 */   public static final Class<String> STRING_VALUE = String.class;
/*     */ 
/*  79 */   public static final Class<Object> OBJECT_VALUE = Object.class;
/*     */ 
/*  82 */   public static final Class<Number> NUMBER_VALUE = Number.class;
/*     */ 
/*  85 */   public static final Class<Date> DATE_VALUE = Date.class;
/*     */ 
/*  88 */   public static final Class<?> CLASS_VALUE = Class.class;
/*     */ 
/*  95 */   public static final Class<FileInputStream> EXISTING_FILE_VALUE = FileInputStream.class;
/*     */ 
/*  98 */   public static final Class<File> FILE_VALUE = File.class;
/*     */ 
/* 101 */   public static final Class<File[]> FILES_VALUE = [Ljava.io.File.class;
/*     */ 
/* 104 */   public static final Class<URL> URL_VALUE = URL.class;
/*     */ 
/*     */   public static Object getValueClass(char ch)
/*     */   {
/* 113 */     switch (ch) {
/*     */     case '@':
/* 115 */       return OBJECT_VALUE;
/*     */     case ':':
/* 117 */       return STRING_VALUE;
/*     */     case '%':
/* 119 */       return NUMBER_VALUE;
/*     */     case '+':
/* 121 */       return CLASS_VALUE;
/*     */     case '#':
/* 123 */       return DATE_VALUE;
/*     */     case '<':
/* 125 */       return EXISTING_FILE_VALUE;
/*     */     case '>':
/* 127 */       return FILE_VALUE;
/*     */     case '*':
/* 129 */       return FILES_VALUE;
/*     */     case '/':
/* 131 */       return URL_VALUE;
/*     */     case '$':
/*     */     case '&':
/*     */     case '\'':
/*     */     case '(':
/*     */     case ')':
/*     */     case ',':
/*     */     case '-':
/*     */     case '.':
/*     */     case '0':
/*     */     case '1':
/*     */     case '2':
/*     */     case '3':
/*     */     case '4':
/*     */     case '5':
/*     */     case '6':
/*     */     case '7':
/*     */     case '8':
/*     */     case '9':
/*     */     case ';':
/*     */     case '=':
/* 134 */     case '?': } return null;
/*     */   }
/*     */ 
/*     */   public static boolean isValueCode(char ch)
/*     */   {
/* 144 */     return (ch == '@') || (ch == ':') || (ch == '%') || (ch == '+') || (ch == '#') || (ch == '<') || (ch == '>') || (ch == '*') || (ch == '/') || (ch == '!');
/*     */   }
/*     */ 
/*     */   public static Options parsePattern(String pattern)
/*     */   {
/* 154 */     char opt = ' ';
/* 155 */     boolean required = false;
/* 156 */     Class type = null;
/*     */ 
/* 158 */     Options options = new Options();
/*     */ 
/* 160 */     for (int i = 0; i < pattern.length(); i++) {
/* 161 */       char ch = pattern.charAt(i);
/*     */ 
/* 165 */       if (!isValueCode(ch)) {
/* 166 */         if (opt != ' ') {
/* 167 */           Option option = Option.builder(String.valueOf(opt)).hasArg(type != null).required(required).type(type).build();
/*     */ 
/* 170 */           options.addOption(option);
/* 171 */           required = false;
/* 172 */           type = null;
/* 173 */           opt = ' ';
/*     */         }
/*     */ 
/* 176 */         opt = ch;
/* 177 */       } else if (ch == '!') {
/* 178 */         required = true;
/*     */       } else {
/* 180 */         type = (Class)getValueClass(ch);
/*     */       }
/*     */     }
/*     */ 
/* 184 */     if (opt != ' ') {
/* 185 */       Option option = Option.builder(String.valueOf(opt)).hasArg(type != null).required(required).type(type).build();
/*     */ 
/* 188 */       options.addOption(option);
/*     */     }
/*     */ 
/* 191 */     return options;
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.PatternOptionBuilder
 * JD-Core Version:    0.6.0
 */