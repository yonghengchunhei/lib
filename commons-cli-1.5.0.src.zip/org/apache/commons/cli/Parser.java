/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Properties;
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class Parser
/*     */   implements CommandLineParser
/*     */ {
/*     */   protected CommandLine cmd;
/*     */   private Options options;
/*     */   private List requiredOptions;
/*     */ 
/*     */   protected void checkRequiredOptions()
/*     */     throws MissingOptionException
/*     */   {
/*  50 */     if (!getRequiredOptions().isEmpty())
/*  51 */       throw new MissingOptionException(getRequiredOptions());
/*     */   }
/*     */ 
/*     */   protected abstract String[] flatten(Options paramOptions, String[] paramArrayOfString, boolean paramBoolean)
/*     */     throws ParseException;
/*     */ 
/*     */   protected Options getOptions()
/*     */   {
/*  67 */     return this.options;
/*     */   }
/*     */ 
/*     */   protected List getRequiredOptions() {
/*  71 */     return this.requiredOptions;
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments)
/*     */     throws ParseException
/*     */   {
/*  84 */     return parse(options, arguments, null, false);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, boolean stopAtNonOption)
/*     */     throws ParseException
/*     */   {
/* 100 */     return parse(options, arguments, null, stopAtNonOption);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, Properties properties)
/*     */     throws ParseException
/*     */   {
/* 115 */     return parse(options, arguments, properties, false);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, Properties properties, boolean stopAtNonOption)
/*     */     throws ParseException
/*     */   {
/* 136 */     for (Option opt : options.helpOptions()) {
/* 137 */       opt.clearValues();
/*     */     }
/*     */ 
/* 141 */     for (OptionGroup group : options.getOptionGroups()) {
/* 142 */       group.setSelected(null);
/*     */     }
/*     */ 
/* 146 */     setOptions(options);
/*     */ 
/* 148 */     this.cmd = new CommandLine();
/*     */ 
/* 150 */     boolean eatTheRest = false;
/*     */ 
/* 152 */     if (arguments == null) {
/* 153 */       arguments = new String[0];
/*     */     }
/*     */ 
/* 156 */     List tokenList = Arrays.asList(flatten(getOptions(), arguments, stopAtNonOption));
/*     */ 
/* 158 */     ListIterator iterator = tokenList.listIterator();
/*     */ 
/* 161 */     while (iterator.hasNext()) {
/* 162 */       String t = (String)iterator.next();
/*     */ 
/* 165 */       if ("--".equals(t)) {
/* 166 */         eatTheRest = true;
/*     */       }
/* 170 */       else if ("-".equals(t)) {
/* 171 */         if (stopAtNonOption)
/* 172 */           eatTheRest = true;
/*     */         else {
/* 174 */           this.cmd.addArg(t);
/*     */         }
/*     */ 
/*     */       }
/* 179 */       else if (t.startsWith("-")) {
/* 180 */         if ((stopAtNonOption) && (!getOptions().hasOption(t))) {
/* 181 */           eatTheRest = true;
/* 182 */           this.cmd.addArg(t);
/*     */         } else {
/* 184 */           processOption(t, iterator);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 190 */         this.cmd.addArg(t);
/*     */ 
/* 192 */         if (stopAtNonOption) {
/* 193 */           eatTheRest = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 198 */       if (eatTheRest) {
/* 199 */         while (iterator.hasNext()) {
/* 200 */           String str = (String)iterator.next();
/*     */ 
/* 203 */           if (!"--".equals(str)) {
/* 204 */             this.cmd.addArg(str);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 210 */     processProperties(properties);
/* 211 */     checkRequiredOptions();
/*     */ 
/* 213 */     return this.cmd;
/*     */   }
/*     */ 
/*     */   public void processArgs(Option opt, ListIterator<String> iter)
/*     */     throws ParseException
/*     */   {
/* 227 */     while (iter.hasNext()) {
/* 228 */       String str = (String)iter.next();
/*     */ 
/* 231 */       if ((getOptions().hasOption(str)) && (str.startsWith("-"))) {
/* 232 */         iter.previous();
/* 233 */         break;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 238 */         opt.addValueForProcessing(Util.stripLeadingAndTrailingQuotes(str));
/*     */       } catch (RuntimeException exp) {
/* 240 */         iter.previous();
/* 241 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 245 */     if ((opt.getValues() == null) && (!opt.hasOptionalArg()))
/* 246 */       throw new MissingArgumentException(opt);
/*     */   }
/*     */ 
/*     */   protected void processOption(String arg, ListIterator<String> iter)
/*     */     throws ParseException
/*     */   {
/* 260 */     boolean hasOption = getOptions().hasOption(arg);
/*     */ 
/* 263 */     if (!hasOption) {
/* 264 */       throw new UnrecognizedOptionException("Unrecognized option: " + arg, arg);
/*     */     }
/*     */ 
/* 268 */     Option opt = (Option)getOptions().getOption(arg).clone();
/*     */ 
/* 271 */     updateRequiredOptions(opt);
/*     */ 
/* 274 */     if (opt.hasArg()) {
/* 275 */       processArgs(opt, iter);
/*     */     }
/*     */ 
/* 279 */     this.cmd.addOption(opt);
/*     */   }
/*     */ 
/*     */   protected void processProperties(Properties properties)
/*     */     throws ParseException
/*     */   {
/* 289 */     if (properties == null) {
/* 290 */       return;
/*     */     }
/*     */ 
/* 293 */     for (Enumeration e = properties.propertyNames(); e.hasMoreElements(); ) {
/* 294 */       String option = e.nextElement().toString();
/*     */ 
/* 296 */       Option opt = this.options.getOption(option);
/* 297 */       if (opt == null) {
/* 298 */         throw new UnrecognizedOptionException("Default option wasn't defined", option);
/*     */       }
/*     */ 
/* 302 */       OptionGroup group = this.options.getOptionGroup(opt);
/* 303 */       boolean selected = (group != null) && (group.getSelected() != null);
/*     */ 
/* 305 */       if ((!this.cmd.hasOption(option)) && (!selected))
/*     */       {
/* 307 */         String value = properties.getProperty(option);
/*     */ 
/* 309 */         if (opt.hasArg()) {
/* 310 */           if ((opt.getValues() == null) || (opt.getValues().length == 0))
/*     */             try {
/* 312 */               opt.addValueForProcessing(value);
/*     */             }
/*     */             catch (RuntimeException localRuntimeException) {
/*     */             }
/*     */         }
/* 317 */         else if ((!"yes".equalsIgnoreCase(value)) && (!"true".equalsIgnoreCase(value)) && (!"1".equalsIgnoreCase(value)))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/*     */ 
/* 323 */         this.cmd.addOption(opt);
/* 324 */         updateRequiredOptions(opt);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setOptions(Options options) {
/* 330 */     this.options = options;
/* 331 */     this.requiredOptions = new ArrayList(options.getRequiredOptions());
/*     */   }
/*     */ 
/*     */   private void updateRequiredOptions(Option opt)
/*     */     throws ParseException
/*     */   {
/* 342 */     if (opt.isRequired()) {
/* 343 */       getRequiredOptions().remove(opt.getKey());
/*     */     }
/*     */ 
/* 348 */     if (getOptions().getOptionGroup(opt) != null) {
/* 349 */       OptionGroup group = getOptions().getOptionGroup(opt);
/*     */ 
/* 351 */       if (group.isRequired()) {
/* 352 */         getRequiredOptions().remove(group);
/*     */       }
/*     */ 
/* 355 */       group.setSelected(opt);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.Parser
 * JD-Core Version:    0.6.0
 */