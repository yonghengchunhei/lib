/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class OptionGroup
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  34 */   private final Map<String, Option> optionMap = new LinkedHashMap();
/*     */   private String selected;
/*     */   private boolean required;
/*     */ 
/*     */   public OptionGroup addOption(Option option)
/*     */   {
/*  51 */     this.optionMap.put(option.getKey(), option);
/*     */ 
/*  53 */     return this;
/*     */   }
/*     */ 
/*     */   public Collection<String> getNames()
/*     */   {
/*  61 */     return this.optionMap.keySet();
/*     */   }
/*     */ 
/*     */   public Collection<Option> getOptions()
/*     */   {
/*  69 */     return this.optionMap.values();
/*     */   }
/*     */ 
/*     */   public String getSelected()
/*     */   {
/*  76 */     return this.selected;
/*     */   }
/*     */ 
/*     */   public boolean isRequired()
/*     */   {
/*  85 */     return this.required;
/*     */   }
/*     */ 
/*     */   public void setRequired(boolean required)
/*     */   {
/*  92 */     this.required = required;
/*     */   }
/*     */ 
/*     */   public void setSelected(Option option)
/*     */     throws AlreadySelectedException
/*     */   {
/* 102 */     if (option == null)
/*     */     {
/* 104 */       this.selected = null;
/* 105 */       return;
/*     */     }
/*     */ 
/* 111 */     if ((this.selected != null) && (!this.selected.equals(option.getKey()))) {
/* 112 */       throw new AlreadySelectedException(this, option);
/*     */     }
/* 114 */     this.selected = option.getKey();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 124 */     StringBuilder buff = new StringBuilder();
/*     */ 
/* 126 */     Iterator iter = getOptions().iterator();
/*     */ 
/* 128 */     buff.append("[");
/*     */ 
/* 130 */     while (iter.hasNext()) {
/* 131 */       Option option = (Option)iter.next();
/*     */ 
/* 133 */       if (option.getOpt() != null) {
/* 134 */         buff.append("-");
/* 135 */         buff.append(option.getOpt());
/*     */       } else {
/* 137 */         buff.append("--");
/* 138 */         buff.append(option.getLongOpt());
/*     */       }
/*     */ 
/* 141 */       if (option.getDescription() != null) {
/* 142 */         buff.append(" ");
/* 143 */         buff.append(option.getDescription());
/*     */       }
/*     */ 
/* 146 */       if (iter.hasNext()) {
/* 147 */         buff.append(", ");
/*     */       }
/*     */     }
/*     */ 
/* 151 */     buff.append("]");
/*     */ 
/* 153 */     return buff.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.OptionGroup
 * JD-Core Version:    0.6.0
 */