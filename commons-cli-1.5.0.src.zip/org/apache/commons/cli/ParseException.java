/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ public class ParseException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 9112808380089253192L;
/*    */ 
/*    */   public ParseException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.ParseException
 * JD-Core Version:    0.6.0
 */