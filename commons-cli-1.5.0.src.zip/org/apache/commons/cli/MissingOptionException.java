/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MissingOptionException extends ParseException
/*    */ {
/*    */   private static final long serialVersionUID = 8161889051578563249L;
/*    */   private List missingOptions;
/*    */ 
/*    */   private static String createMessage(List<?> missingOptions)
/*    */   {
/* 37 */     StringBuilder buf = new StringBuilder("Missing required option");
/* 38 */     buf.append(missingOptions.size() == 1 ? "" : "s");
/* 39 */     buf.append(": ");
/*    */ 
/* 41 */     Iterator it = missingOptions.iterator();
/* 42 */     while (it.hasNext()) {
/* 43 */       buf.append(it.next());
/* 44 */       if (it.hasNext()) {
/* 45 */         buf.append(", ");
/*    */       }
/*    */     }
/*    */ 
/* 49 */     return buf.toString();
/*    */   }
/*    */ 
/*    */   public MissingOptionException(List missingOptions)
/*    */   {
/* 62 */     this(createMessage(missingOptions));
/* 63 */     this.missingOptions = missingOptions;
/*    */   }
/*    */ 
/*    */   public MissingOptionException(String message)
/*    */   {
/* 72 */     super(message);
/*    */   }
/*    */ 
/*    */   public List getMissingOptions()
/*    */   {
/* 83 */     return this.missingOptions;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.MissingOptionException
 * JD-Core Version:    0.6.0
 */