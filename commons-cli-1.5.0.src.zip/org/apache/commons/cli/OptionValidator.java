/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ final class OptionValidator
/*    */ {
/*    */   private static boolean isValidChar(char c)
/*    */   {
/* 33 */     return Character.isJavaIdentifierPart(c);
/*    */   }
/*    */ 
/*    */   private static boolean isValidOpt(char c)
/*    */   {
/* 43 */     return (isValidChar(c)) || (c == '?') || (c == '@');
/*    */   }
/*    */ 
/*    */   static String validate(String option)
/*    */     throws IllegalArgumentException
/*    */   {
/* 62 */     if (option == null)
/* 63 */       return null;
/*    */     char ch;
/* 67 */     if (option.length() == 1) {
/* 68 */       ch = option.charAt(0);
/*    */ 
/* 70 */       if (!isValidOpt(ch))
/* 71 */         throw new IllegalArgumentException("Illegal option name '" + ch + "'");
/*    */     }
/*    */     else
/*    */     {
/* 75 */       for (char ch : option.toCharArray()) {
/* 76 */         if (!isValidChar(ch)) {
/* 77 */           throw new IllegalArgumentException("The option '" + option + "' contains an illegal character : '" + ch + "'");
/*    */         }
/*    */       }
/*    */     }
/* 81 */     return option;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.OptionValidator
 * JD-Core Version:    0.6.0
 */