/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ public class MissingArgumentException extends ParseException
/*    */ {
/*    */   private static final long serialVersionUID = -7098538588704965017L;
/*    */   private Option option;
/*    */ 
/*    */   public MissingArgumentException(Option option)
/*    */   {
/* 39 */     this("Missing argument for option: " + option.getKey());
/* 40 */     this.option = option;
/*    */   }
/*    */ 
/*    */   public MissingArgumentException(String message)
/*    */   {
/* 49 */     super(message);
/*    */   }
/*    */ 
/*    */   public Option getOption()
/*    */   {
/* 59 */     return this.option;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.MissingArgumentException
 * JD-Core Version:    0.6.0
 */