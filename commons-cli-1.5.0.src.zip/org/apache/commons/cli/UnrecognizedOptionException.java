/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ public class UnrecognizedOptionException extends ParseException
/*    */ {
/*    */   private static final long serialVersionUID = -252504690284625623L;
/*    */   private final String option;
/*    */ 
/*    */   public UnrecognizedOptionException(String message)
/*    */   {
/* 39 */     this(message, null);
/*    */   }
/*    */ 
/*    */   public UnrecognizedOptionException(String message, String option)
/*    */   {
/* 50 */     super(message);
/* 51 */     this.option = option;
/*    */   }
/*    */ 
/*    */   public String getOption()
/*    */   {
/* 61 */     return this.option;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.UnrecognizedOptionException
 * JD-Core Version:    0.6.0
 */