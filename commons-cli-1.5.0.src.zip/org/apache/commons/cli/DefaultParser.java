/*     */ package org.apache.commons.cli;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class DefaultParser
/*     */   implements CommandLineParser
/*     */ {
/*     */   protected CommandLine cmd;
/*     */   protected Options options;
/*     */   protected boolean stopAtNonOption;
/*     */   protected String currentToken;
/*     */   protected Option currentOption;
/*     */   protected boolean skipParsing;
/*     */   protected List expectedOpts;
/*     */   private final boolean allowPartialMatching;
/*     */   private final Boolean stripLeadingAndTrailingQuotes;
/*     */ 
/*     */   public static Builder builder()
/*     */   {
/* 129 */     return new Builder(null);
/*     */   }
/*     */ 
/*     */   public DefaultParser()
/*     */   {
/* 183 */     this.allowPartialMatching = true;
/* 184 */     this.stripLeadingAndTrailingQuotes = null;
/*     */   }
/*     */ 
/*     */   public DefaultParser(boolean allowPartialMatching)
/*     */   {
/* 209 */     this.allowPartialMatching = allowPartialMatching;
/* 210 */     this.stripLeadingAndTrailingQuotes = null;
/*     */   }
/*     */ 
/*     */   private DefaultParser(boolean allowPartialMatching, Boolean stripLeadingAndTrailingQuotes)
/*     */   {
/* 222 */     this.allowPartialMatching = allowPartialMatching;
/* 223 */     this.stripLeadingAndTrailingQuotes = stripLeadingAndTrailingQuotes;
/*     */   }
/*     */ 
/*     */   private void checkRequiredArgs()
/*     */     throws ParseException
/*     */   {
/* 230 */     if ((this.currentOption != null) && (this.currentOption.requiresArg()))
/* 231 */       throw new MissingArgumentException(this.currentOption);
/*     */   }
/*     */ 
/*     */   protected void checkRequiredOptions()
/*     */     throws MissingOptionException
/*     */   {
/* 242 */     if (!this.expectedOpts.isEmpty())
/* 243 */       throw new MissingOptionException(this.expectedOpts);
/*     */   }
/*     */ 
/*     */   private String getLongPrefix(String token)
/*     */   {
/* 253 */     String t = Util.stripLeadingHyphens(token);
/*     */ 
/* 256 */     String opt = null;
/* 257 */     for (int i = t.length() - 2; i > 1; i--) {
/* 258 */       String prefix = t.substring(0, i);
/* 259 */       if (this.options.hasLongOption(prefix)) {
/* 260 */         opt = prefix;
/* 261 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 265 */     return opt;
/*     */   }
/*     */ 
/*     */   private List<String> getMatchingLongOptions(String token)
/*     */   {
/* 275 */     if (this.allowPartialMatching) {
/* 276 */       return this.options.getMatchingOptions(token);
/*     */     }
/* 278 */     List matches = new ArrayList(1);
/* 279 */     if (this.options.hasLongOption(token)) {
/* 280 */       Option option = this.options.getOption(token);
/* 281 */       matches.add(option.getLongOpt());
/*     */     }
/*     */ 
/* 284 */     return matches;
/*     */   }
/*     */ 
/*     */   protected void handleConcatenatedOptions(String token)
/*     */     throws ParseException
/*     */   {
/* 308 */     for (int i = 1; i < token.length(); i++) {
/* 309 */       String ch = String.valueOf(token.charAt(i));
/*     */ 
/* 311 */       if (!this.options.hasOption(ch)) {
/* 312 */         handleUnknownToken((this.stopAtNonOption) && (i > 1) ? token.substring(i) : token);
/* 313 */         break;
/*     */       }
/* 315 */       handleOption(this.options.getOption(ch));
/*     */ 
/* 317 */       if ((this.currentOption == null) || (token.length() == i + 1))
/*     */         continue;
/* 319 */       this.currentOption.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOff(token.substring(i + 1)));
/* 320 */       break;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleLongOption(String token)
/*     */     throws ParseException
/*     */   {
/* 333 */     if (token.indexOf(61) == -1)
/* 334 */       handleLongOptionWithoutEqual(token);
/*     */     else
/* 336 */       handleLongOptionWithEqual(token);
/*     */   }
/*     */ 
/*     */   private void handleLongOptionWithEqual(String token)
/*     */     throws ParseException
/*     */   {
/* 348 */     int pos = token.indexOf(61);
/*     */ 
/* 350 */     String value = token.substring(pos + 1);
/*     */ 
/* 352 */     String opt = token.substring(0, pos);
/*     */ 
/* 354 */     List matchingOpts = getMatchingLongOptions(opt);
/* 355 */     if (matchingOpts.isEmpty()) {
/* 356 */       handleUnknownToken(this.currentToken); } else {
/* 357 */       if ((matchingOpts.size() > 1) && (!this.options.hasLongOption(opt))) {
/* 358 */         throw new AmbiguousOptionException(opt, matchingOpts);
/*     */       }
/* 360 */       String key = this.options.hasLongOption(opt) ? opt : (String)matchingOpts.get(0);
/* 361 */       Option option = this.options.getOption(key);
/*     */ 
/* 363 */       if (option.acceptsArg()) {
/* 364 */         handleOption(option);
/* 365 */         this.currentOption.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOff(value));
/* 366 */         this.currentOption = null;
/*     */       } else {
/* 368 */         handleUnknownToken(this.currentToken);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleLongOptionWithoutEqual(String token)
/*     */     throws ParseException
/*     */   {
/* 381 */     List matchingOpts = getMatchingLongOptions(token);
/* 382 */     if (matchingOpts.isEmpty()) {
/* 383 */       handleUnknownToken(this.currentToken); } else {
/* 384 */       if ((matchingOpts.size() > 1) && (!this.options.hasLongOption(token))) {
/* 385 */         throw new AmbiguousOptionException(token, matchingOpts);
/*     */       }
/* 387 */       String key = this.options.hasLongOption(token) ? token : (String)matchingOpts.get(0);
/* 388 */       handleOption(this.options.getOption(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleOption(Option option) throws ParseException
/*     */   {
/* 394 */     checkRequiredArgs();
/*     */ 
/* 396 */     option = (Option)option.clone();
/*     */ 
/* 398 */     updateRequiredOptions(option);
/*     */ 
/* 400 */     this.cmd.addOption(option);
/*     */ 
/* 402 */     if (option.hasArg())
/* 403 */       this.currentOption = option;
/*     */     else
/* 405 */       this.currentOption = null;
/*     */   }
/*     */ 
/*     */   private void handleProperties(Properties properties)
/*     */     throws ParseException
/*     */   {
/* 415 */     if (properties == null) {
/* 416 */       return;
/*     */     }
/*     */ 
/* 419 */     for (Enumeration e = properties.propertyNames(); e.hasMoreElements(); ) {
/* 420 */       String option = e.nextElement().toString();
/*     */ 
/* 422 */       Option opt = this.options.getOption(option);
/* 423 */       if (opt == null) {
/* 424 */         throw new UnrecognizedOptionException("Default option wasn't defined", option);
/*     */       }
/*     */ 
/* 428 */       OptionGroup group = this.options.getOptionGroup(opt);
/* 429 */       boolean selected = (group != null) && (group.getSelected() != null);
/*     */ 
/* 431 */       if ((!this.cmd.hasOption(option)) && (!selected))
/*     */       {
/* 433 */         String value = properties.getProperty(option);
/*     */ 
/* 435 */         if (opt.hasArg()) {
/* 436 */           if ((opt.getValues() == null) || (opt.getValues().length == 0))
/* 437 */             opt.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOff(value));
/*     */         }
/* 439 */         else if ((!"yes".equalsIgnoreCase(value)) && (!"true".equalsIgnoreCase(value)) && (!"1".equalsIgnoreCase(value)))
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 444 */         handleOption(opt);
/* 445 */         this.currentOption = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleShortAndLongOption(String token)
/*     */     throws ParseException
/*     */   {
/* 460 */     String t = Util.stripLeadingHyphens(token);
/*     */ 
/* 462 */     int pos = t.indexOf(61);
/*     */ 
/* 464 */     if (t.length() == 1)
/*     */     {
/* 466 */       if (this.options.hasShortOption(t))
/* 467 */         handleOption(this.options.getOption(t));
/*     */       else
/* 469 */         handleUnknownToken(token);
/*     */     }
/* 471 */     else if (pos == -1)
/*     */     {
/* 473 */       if (this.options.hasShortOption(t)) {
/* 474 */         handleOption(this.options.getOption(t));
/* 475 */       } else if (!getMatchingLongOptions(t).isEmpty())
/*     */       {
/* 477 */         handleLongOptionWithoutEqual(token);
/*     */       }
/*     */       else {
/* 480 */         String opt = getLongPrefix(t);
/*     */ 
/* 482 */         if ((opt != null) && (this.options.getOption(opt).acceptsArg())) {
/* 483 */           handleOption(this.options.getOption(opt));
/* 484 */           this.currentOption.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOff(t.substring(opt.length())));
/* 485 */           this.currentOption = null;
/* 486 */         } else if (isJavaProperty(t))
/*     */         {
/* 488 */           handleOption(this.options.getOption(t.substring(0, 1)));
/* 489 */           this.currentOption.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOff(t.substring(1)));
/* 490 */           this.currentOption = null;
/*     */         }
/*     */         else {
/* 493 */           handleConcatenatedOptions(token);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 498 */       String opt = t.substring(0, pos);
/* 499 */       String value = t.substring(pos + 1);
/*     */ 
/* 501 */       if (opt.length() == 1)
/*     */       {
/* 503 */         Option option = this.options.getOption(opt);
/* 504 */         if ((option != null) && (option.acceptsArg())) {
/* 505 */           handleOption(option);
/* 506 */           this.currentOption.addValueForProcessing(value);
/* 507 */           this.currentOption = null;
/*     */         } else {
/* 509 */           handleUnknownToken(token);
/*     */         }
/* 511 */       } else if (isJavaProperty(opt))
/*     */       {
/* 513 */         handleOption(this.options.getOption(opt.substring(0, 1)));
/* 514 */         this.currentOption.addValueForProcessing(opt.substring(1));
/* 515 */         this.currentOption.addValueForProcessing(value);
/* 516 */         this.currentOption = null;
/*     */       }
/*     */       else {
/* 519 */         handleLongOptionWithEqual(token);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void handleToken(String token)
/*     */     throws ParseException
/*     */   {
/* 531 */     this.currentToken = token;
/*     */ 
/* 533 */     if (this.skipParsing)
/* 534 */       this.cmd.addArg(token);
/* 535 */     else if ("--".equals(token))
/* 536 */       this.skipParsing = true;
/* 537 */     else if ((this.currentOption != null) && (this.currentOption.acceptsArg()) && (isArgument(token)))
/* 538 */       this.currentOption.addValueForProcessing(stripLeadingAndTrailingQuotesDefaultOn(token));
/* 539 */     else if (token.startsWith("--"))
/* 540 */       handleLongOption(token);
/* 541 */     else if ((token.startsWith("-")) && (!"-".equals(token)))
/* 542 */       handleShortAndLongOption(token);
/*     */     else {
/* 544 */       handleUnknownToken(token);
/*     */     }
/*     */ 
/* 547 */     if ((this.currentOption != null) && (!this.currentOption.acceptsArg()))
/* 548 */       this.currentOption = null;
/*     */   }
/*     */ 
/*     */   private void handleUnknownToken(String token)
/*     */     throws ParseException
/*     */   {
/* 560 */     if ((token.startsWith("-")) && (token.length() > 1) && (!this.stopAtNonOption)) {
/* 561 */       throw new UnrecognizedOptionException("Unrecognized option: " + token, token);
/*     */     }
/*     */ 
/* 564 */     this.cmd.addArg(token);
/* 565 */     if (this.stopAtNonOption)
/* 566 */       this.skipParsing = true;
/*     */   }
/*     */ 
/*     */   private boolean isArgument(String token)
/*     */   {
/* 576 */     return (!isOption(token)) || (isNegativeNumber(token));
/*     */   }
/*     */ 
/*     */   private boolean isJavaProperty(String token)
/*     */   {
/* 583 */     String opt = token.substring(0, 1);
/* 584 */     Option option = this.options.getOption(opt);
/*     */ 
/* 586 */     return (option != null) && ((option.getArgs() >= 2) || (option.getArgs() == -2));
/*     */   }
/*     */ 
/*     */   private boolean isLongOption(String token)
/*     */   {
/* 595 */     if ((token == null) || (!token.startsWith("-")) || (token.length() == 1)) {
/* 596 */       return false;
/*     */     }
/*     */ 
/* 599 */     int pos = token.indexOf("=");
/* 600 */     String t = pos == -1 ? token : token.substring(0, pos);
/*     */ 
/* 602 */     if (!getMatchingLongOptions(t).isEmpty())
/*     */     {
/* 604 */       return true;
/*     */     }
/*     */ 
/* 608 */     return (getLongPrefix(token) != null) && (!token.startsWith("--"));
/*     */   }
/*     */ 
/*     */   private boolean isNegativeNumber(String token)
/*     */   {
/*     */     try
/*     */     {
/* 621 */       Double.parseDouble(token);
/* 622 */       return true; } catch (NumberFormatException e) {
/*     */     }
/* 624 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isOption(String token)
/*     */   {
/* 634 */     return (isLongOption(token)) || (isShortOption(token));
/*     */   }
/*     */ 
/*     */   private boolean isShortOption(String token)
/*     */   {
/* 644 */     if ((token == null) || (!token.startsWith("-")) || (token.length() == 1)) {
/* 645 */       return false;
/*     */     }
/*     */ 
/* 649 */     int pos = token.indexOf("=");
/* 650 */     String optName = pos == -1 ? token.substring(1) : token.substring(1, pos);
/* 651 */     if (this.options.hasShortOption(optName)) {
/* 652 */       return true;
/*     */     }
/*     */ 
/* 655 */     return (!optName.isEmpty()) && (this.options.hasShortOption(String.valueOf(optName.charAt(0))));
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments) throws ParseException
/*     */   {
/* 660 */     return parse(options, arguments, null);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, boolean stopAtNonOption) throws ParseException
/*     */   {
/* 665 */     return parse(options, arguments, null, stopAtNonOption);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, Properties properties)
/*     */     throws ParseException
/*     */   {
/* 679 */     return parse(options, arguments, properties, false);
/*     */   }
/*     */ 
/*     */   public CommandLine parse(Options options, String[] arguments, Properties properties, boolean stopAtNonOption)
/*     */     throws ParseException
/*     */   {
/* 697 */     this.options = options;
/* 698 */     this.stopAtNonOption = stopAtNonOption;
/* 699 */     this.skipParsing = false;
/* 700 */     this.currentOption = null;
/* 701 */     this.expectedOpts = new ArrayList(options.getRequiredOptions());
/*     */ 
/* 704 */     for (Object localObject = options.getOptionGroups().iterator(); ((Iterator)localObject).hasNext(); ) { group = (OptionGroup)((Iterator)localObject).next();
/* 705 */       group.setSelected(null);
/*     */     }
/*     */     OptionGroup group;
/* 708 */     this.cmd = new CommandLine();
/*     */ 
/* 710 */     if (arguments != null) {
/* 711 */       localObject = arguments; group = localObject.length; for (OptionGroup localOptionGroup1 = 0; localOptionGroup1 < group; localOptionGroup1++) { String argument = localObject[localOptionGroup1];
/* 712 */         handleToken(argument);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 717 */     checkRequiredArgs();
/*     */ 
/* 720 */     handleProperties(properties);
/*     */ 
/* 722 */     checkRequiredOptions();
/*     */ 
/* 724 */     return (CommandLine)this.cmd;
/*     */   }
/*     */ 
/*     */   private String stripLeadingAndTrailingQuotesDefaultOff(String token)
/*     */   {
/* 735 */     if ((this.stripLeadingAndTrailingQuotes != null) && (this.stripLeadingAndTrailingQuotes.booleanValue())) {
/* 736 */       return Util.stripLeadingAndTrailingQuotes(token);
/*     */     }
/* 738 */     return token;
/*     */   }
/*     */ 
/*     */   private String stripLeadingAndTrailingQuotesDefaultOn(String token)
/*     */   {
/* 749 */     if ((this.stripLeadingAndTrailingQuotes == null) || (this.stripLeadingAndTrailingQuotes.booleanValue())) {
/* 750 */       return Util.stripLeadingAndTrailingQuotes(token);
/*     */     }
/* 752 */     return token;
/*     */   }
/*     */ 
/*     */   private void updateRequiredOptions(Option option)
/*     */     throws AlreadySelectedException
/*     */   {
/* 761 */     if (option.isRequired()) {
/* 762 */       this.expectedOpts.remove(option.getKey());
/*     */     }
/*     */ 
/* 766 */     if (this.options.getOptionGroup(option) != null) {
/* 767 */       OptionGroup group = this.options.getOptionGroup(option);
/*     */ 
/* 769 */       if (group.isRequired()) {
/* 770 */         this.expectedOpts.remove(group);
/*     */       }
/*     */ 
/* 773 */       group.setSelected(option);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final class Builder
/*     */   {
/*  49 */     private boolean allowPartialMatching = true;
/*     */     private Boolean stripLeadingAndTrailingQuotes;
/*     */ 
/*     */     public DefaultParser build()
/*     */     {
/*  70 */       return new DefaultParser(this.allowPartialMatching, this.stripLeadingAndTrailingQuotes, null);
/*     */     }
/*     */ 
/*     */     public Builder setAllowPartialMatching(boolean allowPartialMatching)
/*     */     {
/*  96 */       this.allowPartialMatching = allowPartialMatching;
/*  97 */       return this;
/*     */     }
/*     */ 
/*     */     public Builder setStripLeadingAndTrailingQuotes(Boolean stripLeadingAndTrailingQuotes)
/*     */     {
/* 116 */       this.stripLeadingAndTrailingQuotes = stripLeadingAndTrailingQuotes;
/* 117 */       return this;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.DefaultParser
 * JD-Core Version:    0.6.0
 */