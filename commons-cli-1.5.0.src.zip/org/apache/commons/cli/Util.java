/*    */ package org.apache.commons.cli;
/*    */ 
/*    */ final class Util
/*    */ {
/* 28 */   static final String[] EMPTY_STRING_ARRAY = new String[0];
/*    */ 
/*    */   static String stripLeadingAndTrailingQuotes(String str)
/*    */   {
/* 38 */     int length = str.length();
/* 39 */     if ((length > 1) && (str.startsWith("\"")) && (str.endsWith("\"")) && (str.substring(1, length - 1).indexOf('"') == -1)) {
/* 40 */       str = str.substring(1, length - 1);
/*    */     }
/*    */ 
/* 43 */     return str;
/*    */   }
/*    */ 
/*    */   static String stripLeadingHyphens(String str)
/*    */   {
/* 54 */     if (str == null) {
/* 55 */       return null;
/*    */     }
/* 57 */     if (str.startsWith("--")) {
/* 58 */       return str.substring(2);
/*    */     }
/* 60 */     if (str.startsWith("-")) {
/* 61 */       return str.substring(1);
/*    */     }
/*    */ 
/* 64 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\1045139978qq.com\Desktop\dependency-check\lib\commons-cli-1.5.0.jar
 * Qualified Name:     org.apache.commons.cli.Util
 * JD-Core Version:    0.6.0
 */